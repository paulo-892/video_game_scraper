# -*- test-case-name: twisted.words.test -*-
# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

"""
Twisted Words: Client and server implementations for IRC, XMPP, and other chat
services.
"""
